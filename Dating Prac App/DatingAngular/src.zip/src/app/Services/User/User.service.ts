import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import { Http, RequestOptions, Headers } from '@angular/http';
import {Observable } from 'rxjs';
import { User } from '../../Models/User';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';


@Injectable({
  providedIn: 'root'
})
export class UserService {



baseUrl: string = environment.apiUrl;
constructor(private http: Http) { }

getUsers(): Observable<User[]> {
  return this.http.get(this.baseUrl + 'Users', this.jwt())
  .map((response) => response.status === 204 ? null : <User[]>response.json())
  .catch(error => Observable.throw(error.json()));
}

private jwt() {
  const token = localStorage.getItem('token');
  if (token) {
    const headers = new Headers({'Authorization': 'Bearer ' + token});
    headers.append('Content-type', 'application/json');
    return new RequestOptions({headers: headers});
  }
}



public HandleError(error: any) {
  debugger;
  const _applicationError = error.headers.get('Application-Error');
  if (_applicationError) {
    return Observable.throw(_applicationError);
  }
  let _modelError = '';
  const _serverError = error.json();
  if (_serverError) {
    for (const key in _serverError) {
       if (_serverError) {
          _modelError += _serverError[key];
       }
    }
  }
  return Observable.throw(_modelError || 'Server error');
}


}
