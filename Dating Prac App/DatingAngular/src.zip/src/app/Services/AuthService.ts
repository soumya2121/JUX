import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers, Response } from '@angular/http';
import {Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { tokenNotExpired } from 'angular2-jwt';


@Injectable()
export class AuthService {
  _baseUrl = 'http://localhost:51250/api/Auth/';
  _userToken: any;
  _decodeToken: any;
  constructor(private http: Http) {}
  Login(model: any) {
   return  this.http.post(this._baseUrl + 'login', model, this.Option()).map((response) => {
      const user = response.json();
      if (user) {
        localStorage.setItem('token', user.tokenString);
        this._userToken = user.tokenString;
      }
    }).catch(this.HandleError);
  }

  Register(model: any) {
return this.http.post(this._baseUrl + 'register', model, this.Option()).catch(this.HandleError);
  }

  public Option() {
    const _headers = new Headers({ 'Content-type': 'application/json' });
    const _options = new RequestOptions({ headers: _headers });
    return _options;
  }

  public HandleError(error: any) {
    const _applicationError = error.headers.get('Application-Error');
    if (_applicationError) {
      return Observable.throw(_applicationError);
    }
    let _modelError = '';
    const _serverError = error.json();
    if (_serverError) {
      for (const key in _serverError) {
         if (_serverError) {
            _modelError += _serverError[key];
         }
      }
    }
    return Observable.throw(_modelError || 'Server error');
  }

  LoggedIn() {
   return tokenNotExpired('token', localStorage.getItem('token'));
  }
}
