import { Photo } from './Photo';

export class User {
    id: number;
    username: string;
    knownAs: string;
    age: number;
    gender: string;
    created: Date;
    lastActive: Date;
    photoUrl: string;
    city: String;
    country: string;
    Interests?: string;
    Introduction?: string;
    LookingFor?: string;
    Photos?: Photo[];
}
