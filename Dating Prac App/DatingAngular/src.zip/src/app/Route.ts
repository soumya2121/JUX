
import { RouterModule, Routes } from '@angular/router';
import { Component } from '@angular/core';
import { HomeComponent } from './Home/Home.component';
import { MessagesComponent } from './messages/messages.component';
import { ListsComponent } from './lists/lists.component';
import { AuthGuard } from './Guards/auth.guard';
import { MemberListComponent } from './Member-List/Member-List.component';
import { MatchListComponent } from './MatchList/MatchList.component';


export const appRoutes: Routes = [
{path : 'home', component: HomeComponent },
{
    path: '',
    runGuardsAndResolvers: 'always',
    children: [
        {path : 'messages', component : MessagesComponent},
        {path : 'lists', component : ListsComponent},
        {path : 'members', component : MatchListComponent},
    ],
    canActivate: [AuthGuard]
},
{path : '**', redirectTo: 'home', pathMatch: 'full' },
];
