import { Component, OnInit } from '@angular/core';
import { User } from '../Models/User';
import { UserService } from '../Services/User/User.service';
import { AlertifyService } from '../Services/Alertify/AlertifyService.service';
import { error } from 'protractor';

@Component({
  selector: 'app-MatchList',
  templateUrl: './MatchList.component.html',
  styleUrls: ['./MatchList.component.css']
})
export class MatchListComponent implements OnInit {
users: User[];
  constructor(private userService: UserService, private alertify: AlertifyService) { }

  ngOnInit() {
    this.getUsers();
  }
  getUsers() {
    // tslint:disable-next-line:no-debugger
    debugger;
    console.log('method hit');
    this.userService.getUsers().subscribe((users: User[]) => {
     this.users = users;
    }, error => {
this.alertify.Error(error);
console.log('Users:' + this.users);
    });
  }
}
