import {FormsModule} from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';
import { AppComponent } from './app.component';
import { NavBarComponent } from './NavBar/NavBar.component';
import { AuthService } from './Services/AuthService';
import { RegisterComponent } from './Register/Register.component';
import { HomeComponent } from './Home/Home.component';
import { AlertifyService } from './Services/Alertify/AlertifyService.service';
import { BsDropdownModule } from 'ngx-bootstrap';
import { MessagesComponent } from './messages/messages.component';
import { ListsComponent } from './lists/lists.component';
import { RouterModule } from '@angular/router';
import { appRoutes } from './Route';
import { AuthGuard } from './Guards/auth.guard';
import { UserService } from './Services/User/User.service';
import { MemberListComponent } from './Member-List/Member-List.component';
import { MatchListComponent } from './MatchList/MatchList.component';





@NgModule({
  declarations: [
    AppComponent,
    NavBarComponent,
    RegisterComponent,
    HomeComponent,
    NavBarComponent,
    NavBarComponent,
    NavBarComponent,
    MessagesComponent,
    ListsComponent,
    MemberListComponent,
    MatchListComponent
],
  imports: [
    BrowserModule, HttpModule, FormsModule, BsDropdownModule.forRoot(), RouterModule.forRoot(appRoutes)
  ],
  providers: [AuthService, AlertifyService, AuthGuard, UserService],
  bootstrap: [AppComponent]
})
export class AppModule { }
