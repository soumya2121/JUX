import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Http } from '@angular/http';
import { AuthService } from '../Services/AuthService';
import { error } from 'util';
import {  AlertifyService } from '../Services/Alertify/AlertifyService.service';


@Component({
  selector: 'app-Register',
  templateUrl: './Register.component.html',
  styleUrls: ['./Register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private authservice: AuthService, private alertify: AlertifyService) { }
  model: any = {};
 
  @Output() CancelRegister = new EventEmitter();
  ngOnInit() {
  }
register() {
  console.log('register method hit');
  console.log(this.model);
   this.authservice.Register(this.model).subscribe(() => {
    this.alertify.Success('Successfully registered');
   }, error => { this.alertify.Error(error);}
   );
}

Cancel() {
  this.CancelRegister.emit(false);
}

}
