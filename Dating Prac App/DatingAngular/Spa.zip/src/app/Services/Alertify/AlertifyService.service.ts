import { Injectable } from '@angular/core';
declare let alertify;

@Injectable({
  providedIn: 'root'
})
export class AlertifyService {

constructor() { }

Confirm(message: string, callback: () => any) {
 alertify.confirm(message, function(e) {
   if (e) {
    callback();
   } else {

   }
 });
}
Message(message: string) {
  alertify.message(message);
}

Error(message: string) {
alertify.error(message);
}

Success(message: string) {
alertify.message(message);
}
}


