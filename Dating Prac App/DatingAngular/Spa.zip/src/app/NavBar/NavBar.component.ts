import { Component, OnInit } from '@angular/core';
import { AuthService } from '../Services/AuthService';
import { AlertifyService } from '../Services/Alertify/AlertifyService.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-NavBar',
  templateUrl: './NavBar.component.html',
  styleUrls: ['./NavBar.component.css']
})
export class NavBarComponent implements OnInit {
model: any = { };
  constructor(private authservice: AuthService, private alertify: AlertifyService, private route: Router ) { }

  ngOnInit() {
  }
Login(model: any) {
this.authservice.Login(this.model).subscribe(response => {
this.alertify.Success('Login successful');
}, error => {this.alertify.Error('log in failed');
}, () => {
this.route.navigate(['members']);
});
}

Logout() {
  localStorage.removeItem('token');
  this.authservice._userToken = null;
  this.alertify.Message('logged out successfully');
  this.route.navigate(['home']);
}

LoggedIn() {
  return this.authservice.LoggedIn();
}
}
