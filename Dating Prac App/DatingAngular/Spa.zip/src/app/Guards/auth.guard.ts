import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from '../Services/AuthService';
import { AlertifyService } from '../Services/Alertify/AlertifyService.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {

  constructor(private authservice: AuthService, private alertify: AlertifyService, private route: Router) {}
  canActivate(): Observable<boolean> | Promise<boolean> | boolean {
    if (this.authservice.LoggedIn()) {
      return true;
    }
   this.alertify.Error('Please log in to find your match');
   this.route.navigate(['home']);
   return false;
  }
}
