export interface Photo {
    Id: number;
    Url: string;
    Description: string;
    DateAdded: Date;
    IsMain: boolean;
}
