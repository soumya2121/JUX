import { Component, OnInit } from '@angular/core';
import { UserService } from '../Services/User/User.service';
import { AlertifyService } from '../Services/Alertify/AlertifyService.service';
import { User } from '../Models/User';

@Component({
  selector: 'app-member-list',
  templateUrl: './Member-List.component.html',
  styleUrls: ['./Member-List.component.css']
})
export class MemberListComponent implements OnInit {

  _users: User[];
  constructor(private userService: UserService, private alertify: AlertifyService) { }

  ngOnInit() {
  }
  getUsers() {
    console.log('getUsers hit');
    this.userService.getUsers().subscribe((users: User[]) => {
    this._users = users;
    }, error => {
      this.alertify.Error(error);
   }
   );
  }
}
